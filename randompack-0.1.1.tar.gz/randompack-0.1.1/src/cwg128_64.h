// From Chris Doty-Humphrey's cwg128-64 generator
typedef struct cwg128_64 {
  __uint128_t x;
  uint64_t a;
  uint64_t weyl;
  uint64_t s;
} cwg128_64_t;
